from __future__ import annotations

import enum
import os
import pathlib
import re
import shlex
import signal
import subprocess
import sys
import tempfile
import threading
import traceback

import lit.InprocBuiltins as InprocBuiltins
import lit.ShUtil as ShUtil
import lit.Test as Test
import lit.util
from lit.BooleanExpression import BooleanExpression
from lit.ShCommands import Command
from lit.ShellEnvironment import (
    InternalShellError,
    ShellCommandResult,
    ShellEnvironment,
    expand_glob,
    expand_glob_expressions,
    kAvoidDevNull,
    kDevNull,
    kIsWindows,
    kUseCloseFDs,
    processRedirects,
    quote_windows_command,
    updateEnv,
)


class ScriptFatal(Exception):
    """
    A script had a fatal error such that there's no point in retrying.  The
    message has not been emitted on stdout or stderr but is instead included in
    this exception.
    """

    def __init__(self, message):
        super().__init__(message)


class TestUpdaterException(Exception):
    """
    There was an error not during test execution, but while invoking a function
    in test_updaters on a failing RUN line.
    """

    def __init__(self, message):
        super().__init__(message)


# A regex that matches %dbg(ARG), which lit inserts at the beginning of each
# run command pipeline such that ARG specifies the pipeline's source line
# number.  lit later expands each %dbg(ARG) to a command that behaves as a null
# command in the target shell so that the line number is seen in lit's verbose
# mode.
#
# This regex captures ARG.  ARG must not contain a right parenthesis, which
# terminates %dbg.  ARG must not contain quotes, in which ARG might be enclosed
# during expansion.
#
# COMMAND that follows %dbg(ARG) is also captured. COMMAND can be
# empty as a result of conditinal substitution.
kPdbgRegex = "%dbg\\(([^)'\"]*)\\)((?:.|\\n)*)"


def buildPdbgCommand(msg, cmd):
    res = f"%dbg({msg}) {cmd}"
    assert re.fullmatch(
        kPdbgRegex, res
    ), f"kPdbgRegex expected to match actual %dbg usage: {res}"
    return res


class TimeoutHelper:
    """
    Object used to helper manage enforcing a timeout in
    _executeShCmd(). It is passed through recursive calls
    to collect processes that have been executed so that when
    the timeout happens they can be killed.
    """

    def __init__(self, timeout):
        self.timeout = timeout
        self._procs = []
        self._timeoutReached = False
        self._doneKillPass = False
        # This lock will be used to protect concurrent access
        # to _procs and _doneKillPass
        self._lock = None
        self._timer = None

    def cancel(self):
        if not self.active():
            return
        self._timer.cancel()
        # Break reference cycle so that thread stack is freed immediately.
        self._timer = None

    def active(self):
        return self.timeout > 0

    def addProcess(self, proc):
        if not self.active():
            return
        needToRunKill = False
        with self._lock:
            # just store the pid, rather than the whole proc object.
            # Holding the proc object keeps resources (eg pipes) open unnecessarily.
            self._procs.append(proc.pid)
            # Avoid re-entering the lock by finding out if kill needs to be run
            # again here but call it if necessary once we have left the lock.
            # We could use a reentrant lock here instead but this code seems
            # clearer to me.
            needToRunKill = self._doneKillPass

        # The initial call to _kill() from the timer thread already happened so
        # we need to call it again from this thread, otherwise this process
        # will be left to run even though the timeout was already hit
        if needToRunKill:
            assert self.timeoutReached()
            self._kill()

    def startTimer(self):
        if not self.active():
            return

        # Do some late initialisation that's only needed
        # if there is a timeout set
        self._lock = threading.Lock()
        self._timer = threading.Timer(self.timeout, self._handleTimeoutReached)
        self._timer.start()

    def _handleTimeoutReached(self):
        self._timeoutReached = True
        self._kill()

    def timeoutReached(self):
        return self._timeoutReached

    def _kill(self):
        """
        This method may be called multiple times as we might get unlucky
        and be in the middle of creating a new process in _executeShCmd()
        which won't yet be in ``self._procs``. By locking here and in
        addProcess() we should be able to kill processes launched after
        the initial call to _kill()
        """
        with self._lock:
            for pid in self._procs:
                lit.util.killProcessAndChildren(pid)
            # Empty the list and note that we've done a pass over the list
            self._procs = []  # Python2 doesn't have list.clear()
            self._doneKillPass = True


def executeShCmd(cmd, shenv, results, timeout=0):
    """
    Wrapper around _executeShCmd that handles
    timeout
    """
    # Use the helper even when no timeout is required to make
    # other code simpler (i.e. avoid bunch of ``is not None`` checks)
    timeoutHelper = TimeoutHelper(timeout)
    if timeout > 0:
        timeoutHelper.startTimer()
    try:
        finalExitCode = _executeShCmd(cmd, shenv, results, timeoutHelper)
    except InternalShellError:
        e = sys.exc_info()[1]
        finalExitCode = 127
        results.append(
            ShellCommandResult(e.command, "", e.message, finalExitCode, False)
        )
    timeoutHelper.cancel()
    timeoutInfo = None
    if timeoutHelper.timeoutReached():
        timeoutInfo = "Reached timeout of {} seconds".format(timeout)

    return (finalExitCode, timeoutInfo)


def _expandLateSubstitutions(cmd, arguments, cwd, normalize_slashes=False):
    for i, arg in enumerate(arguments):
        if not isinstance(arg, str):
            continue

        def _replaceReadFile(match):
            filePath = match.group(1)
            if not os.path.isabs(filePath):
                filePath = os.path.join(cwd, filePath)
            if normalize_slashes:
                filePath = filePath.replace("\\", "/")
            try:
                with open(filePath) as fileHandle:
                    return fileHandle.read()
            except FileNotFoundError:
                raise InternalShellError(
                    cmd,
                    "File specified in readfile substitution does not exist: %s"
                    % filePath,
                )

        arguments[i] = re.sub(r"%{readfile:([^}]*)}", _replaceReadFile, arg)

    return arguments


def _executeShCmd(cmd, shenv, results, timeoutHelper):
    if timeoutHelper.timeoutReached():
        # Prevent further recursion if the timeout has been hit
        # as we should try avoid launching more processes.
        return None

    if isinstance(cmd, ShUtil.Seq):
        if cmd.op == ";":
            res = _executeShCmd(cmd.lhs, shenv, results, timeoutHelper)
            return _executeShCmd(cmd.rhs, shenv, results, timeoutHelper)

        if cmd.op == "&":
            raise InternalShellError(cmd, "unsupported shell operator: '&'")

        if cmd.op == "||":
            res = _executeShCmd(cmd.lhs, shenv, results, timeoutHelper)
            if res != 0:
                res = _executeShCmd(cmd.rhs, shenv, results, timeoutHelper)
            return res

        if cmd.op == "&&":
            res = _executeShCmd(cmd.lhs, shenv, results, timeoutHelper)
            if res is None:
                return res

            if res == 0:
                res = _executeShCmd(cmd.rhs, shenv, results, timeoutHelper)
            return res

        raise ValueError("Unknown shell command: %r" % cmd.op)
    assert isinstance(cmd, ShUtil.Pipeline)

    procs = []
    proc_not_counts = []
    proc_not_fail_if_crash = []
    default_stdin = subprocess.PIPE
    stderrTempFiles = []
    opened_files = []
    named_temp_files = []
    builtin_commands = set(["cat", "diff"])
    builtin_commands_dir = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "builtin_commands"
    )
    inproc_builtins = {
        "cd": InprocBuiltins.executeBuiltinCd,
        "export": InprocBuiltins.executeBuiltinExport,
        "echo": InprocBuiltins.executeBuiltinEcho,
        "@echo": InprocBuiltins.executeBuiltinEcho,
        "mkdir": InprocBuiltins.executeBuiltinMkdir,
        "popd": InprocBuiltins.executeBuiltinPopd,
        "pushd": InprocBuiltins.executeBuiltinPushd,
        "rm": InprocBuiltins.executeBuiltinRm,
        "ulimit": InprocBuiltins.executeBuiltinUlimit,
        "umask": InprocBuiltins.executeBuiltinUmask,
        ":": InprocBuiltins.executeBuiltinColon,
    }
    # To avoid deadlock, we use a single stderr stream for piped
    # output. This is null until we have seen some output using
    # stderr.
    for i, j in enumerate(cmd.commands):
        # Reference the global environment by default.
        cmd_shenv = shenv
        args = list(j.args)
        not_args = []
        not_count = 0
        not_crash = False

        # Expand all late substitutions.
        args = _expandLateSubstitutions(
            j, args, cmd_shenv.cwd, cmd_shenv.normalize_slashes
        )

        while True:
            if args[0] == "env":
                # Create a copy of the global environment and modify it for
                # this one command. There might be multiple envs in a pipeline,
                # and there might be multiple envs in a command (usually when
                # one comes from a substitution):
                #   env FOO=1 llc < %s | env BAR=2 llvm-mc | FileCheck %s
                #   env FOO=1 %{another_env_plus_cmd} | FileCheck %s
                if cmd_shenv is shenv:
                    cmd_shenv = ShellEnvironment(
                        shenv.cwd,
                        shenv.env,
                        shenv.umask,
                        normalize_slashes=shenv.normalize_slashes,
                    )
                args = updateEnv(cmd_shenv, args)
                if not args:
                    # Return the environment variables if no argument is provided.
                    env_str = "\n".join(
                        f"{key}={value}" for key, value in sorted(cmd_shenv.env.items())
                    )
                    results.append(
                        ShellCommandResult(
                            j, env_str, "", 0, timeoutHelper.timeoutReached(), []
                        )
                    )
                    return 0
            elif args[0] == "not":
                not_args.append(args.pop(0))
                not_count += 1
                if args and args[0] == "--crash":
                    not_args.append(args.pop(0))
                    not_crash = True
                if not args:
                    raise InternalShellError(j, "Error: 'not' requires a" " subcommand")
            elif args[0] == "!":
                not_args.append(args.pop(0))
                not_count += 1
                if not args:
                    raise InternalShellError(j, "Error: '!' requires a" " subcommand")
            else:
                break

        # Handle in-process builtins.
        #
        # Handle "echo" as a builtin if it is not part of a pipeline. This
        # greatly speeds up tests that construct input files by repeatedly
        # echo-appending to a file.
        # FIXME: Standardize on the builtin echo implementation. We can use a
        # temporary file to sidestep blocking pipe write issues.

        # Ensure args[0] is hashable.
        args[0] = expand_glob(args[0], cmd_shenv.cwd)[0]

        inproc_builtin = inproc_builtins.get(args[0], None)
        if inproc_builtin and (args[0] != "echo" or len(cmd.commands) == 1):
            # env calling an in-process builtin is useless, so we take the safe
            # approach of complaining.
            if not cmd_shenv is shenv:
                raise InternalShellError(
                    j, "Error: 'env' cannot call '{}'".format(args[0])
                )
            if not_crash:
                raise InternalShellError(
                    j, "Error: 'not --crash' cannot call" " '{}'".format(args[0])
                )
            if len(cmd.commands) != 1:
                raise InternalShellError(
                    j,
                    "Unsupported: '{}' cannot be part" " of a pipeline".format(args[0]),
                )
            result = inproc_builtin(Command(args, j.redirects), cmd_shenv)
            if not_count % 2:
                result.exitCode = int(not result.exitCode)
            result.command.args = j.args
            results.append(result)
            return result.exitCode

        # Resolve any out-of-process builtin command before adding back 'not'
        # commands.
        if args[0] in builtin_commands:
            args.insert(0, sys.executable)
            cmd_shenv.env["PYTHONPATH"] = os.path.dirname(os.path.abspath(__file__))
            args[1] = os.path.join(builtin_commands_dir, args[1] + ".py")

        # We had to search through the 'not' commands to find all the 'env'
        # commands and any other in-process builtin command.  We don't want to
        # reimplement 'not' and its '--crash' here, so just push all 'not'
        # commands back to be called as external commands.  Because this
        # approach effectively moves all 'env' commands up front, it relies on
        # the assumptions that (1) environment variables are not intended to be
        # relevant to 'not' commands and (2) the 'env' command should always
        # blindly pass along the status it receives from any command it calls.

        # For plain negations, either 'not' without '--crash', or the shell
        # operator '!', leave them out from the command to execute and
        # invert the result code afterwards. If we have a plain not, pass the
        # args along so we can recognize it later and still fail if the
        # executed command returns a signal.
        if not_crash:
            args = not_args + args
            not_count = 0
        elif not_args == ["not"]:
            pass
        else:
            not_args = []

        stdin, stdout, stderr = processRedirects(
            j, default_stdin, cmd_shenv, opened_files
        )

        # If stderr wants to come from stdout, but stdout isn't a pipe, then put
        # stderr on a pipe and treat it as stdout.
        if stderr == subprocess.STDOUT and stdout != subprocess.PIPE:
            stderr = subprocess.PIPE
            stderrIsStdout = True
        else:
            stderrIsStdout = False

            # Don't allow stderr on a PIPE except for the last
            # process, this could deadlock.
            #
            # FIXME: This is slow, but so is deadlock.
            if stderr == subprocess.PIPE and j != cmd.commands[-1]:
                stderr = tempfile.TemporaryFile(mode="w+b")
                stderrTempFiles.append((i, stderr))

        # Resolve the executable path ourselves.
        executable = None
        # For paths relative to cwd, use the cwd of the shell environment.
        if args[0].startswith("."):
            exe_in_cwd = os.path.join(cmd_shenv.cwd, args[0])
            if os.path.isfile(exe_in_cwd):
                executable = exe_in_cwd
        if not executable:
            # Use the path from cmd_shenv by default, but if the environment variable
            # is unset (like if the user is using env -i), use the standard path.
            path = (
                cmd_shenv.env["PATH"] if "PATH" in cmd_shenv.env else shenv.env["PATH"]
            )
            executable = lit.util.which(args[0], path)
        if not executable:
            raise InternalShellError(j, "%r: command not found" % args[0])

        # Replace uses of /dev/null with temporary files.
        if kAvoidDevNull:
            for i, arg in enumerate(args):
                if isinstance(arg, str) and kDevNull in arg:
                    f = tempfile.NamedTemporaryFile(delete=False)
                    f.close()
                    named_temp_files.append(f.name)
                    args[i] = arg.replace(kDevNull, f.name)

        # Expand all glob expressions
        args = expand_glob_expressions(args, cmd_shenv.cwd)

        # On Windows, do our own command line quoting for better compatibility
        # with some core utility distributions.
        if kIsWindows:
            args = quote_windows_command(args)

        # Handle any resource limits. We do this by launching the command with
        # a wrapper that sets the necessary limits. We use a wrapper rather than
        # setting the limits in process as we cannot reraise the limits back to
        # their defaults without elevated permissions.
        if cmd_shenv.ulimit:
            executable = sys.executable
            args.insert(0, sys.executable)
            args.insert(1, os.path.join(builtin_commands_dir, "_launch_with_limit.py"))
            for limit in cmd_shenv.ulimit:
                cmd_shenv.env["LIT_INTERNAL_ULIMIT_" + limit] = str(
                    cmd_shenv.ulimit[limit]
                )

        try:
            # TODO(boomanaiden154): We currently wrap the subprocess.Popen with
            # os.umask as the umask argument in subprocess.Popen is not
            # available before Python 3.9. Once LLVM requires at least Python
            # 3.9, this code should be updated to use umask argument.
            old_umask = -1
            if cmd_shenv.umask != -1:
                old_umask = os.umask(cmd_shenv.umask)
            procs.append(
                subprocess.Popen(
                    args,
                    cwd=cmd_shenv.cwd,
                    executable=executable,
                    stdin=stdin,
                    stdout=stdout,
                    stderr=stderr,
                    env=cmd_shenv.env,
                    close_fds=kUseCloseFDs,
                    universal_newlines=True,
                    errors="replace",
                )
            )
            if old_umask != -1:
                os.umask(old_umask)
            proc_not_counts.append(not_count)
            if not not_crash and not_args == ["not"]:
                proc_not_fail_if_crash.append(True)
            else:
                proc_not_fail_if_crash.append(False)
            # Let the helper know about this process
            timeoutHelper.addProcess(procs[-1])
        except OSError as e:
            raise InternalShellError(
                j, "Could not create process ({}) due to {}".format(executable, e)
            )

        # Immediately close stdin for any process taking stdin from us.
        if stdin == subprocess.PIPE:
            procs[-1].stdin.close()
            procs[-1].stdin = None

        # Update the current stdin source.
        if stdout == subprocess.PIPE:
            default_stdin = procs[-1].stdout
        elif stderrIsStdout:
            default_stdin = procs[-1].stderr
        else:
            default_stdin = subprocess.PIPE

    # Explicitly close any redirected files. We need to do this now because we
    # need to release any handles we may have on the temporary files (important
    # on Win32, for example). Since we have already spawned the subprocess, our
    # handles have already been transferred so we do not need them anymore.
    for (name, mode, f, path) in opened_files:
        f.close()

    # FIXME: There is probably still deadlock potential here. Yawn.
    procData = [None] * len(procs)
    procData[-1] = procs[-1].communicate()

    for i in range(len(procs) - 1):
        if procs[i].stdout is not None:
            out = procs[i].stdout.read()
        else:
            out = ""
        if procs[i].stderr is not None:
            err = procs[i].stderr.read()
        else:
            err = ""
        procData[i] = (out, err)

    # Read stderr out of the temp files.
    for i, f in stderrTempFiles:
        f.seek(0, 0)
        procData[i] = (procData[i][0], f.read())
        f.close()

    exitCode = None
    for i, (out, err) in enumerate(procData):
        res = procs[i].wait()
        # Detect Ctrl-C in subprocess.
        if res == -signal.SIGINT:
            raise KeyboardInterrupt
        if proc_not_counts[i] % 2:
            if proc_not_fail_if_crash[i]:
                res = int(res <= 0)
            else:
                res = 1 if res == 0 else 0
        elif proc_not_counts[i] > 1:
            res = 1 if res != 0 else 0

        # Ensure the resulting output is always of string type.
        try:
            if out is None:
                out = ""
            else:
                out = out.decode("utf-8", errors="replace")
        except:
            out = str(out)
        try:
            if err is None:
                err = ""
            else:
                err = err.decode("utf-8", errors="replace")
        except:
            err = str(err)

        # Gather the redirected output files for failed commands.
        output_files = []
        if res != 0:
            for (name, mode, f, path) in sorted(opened_files):
                if path is not None and mode in ("w", "a"):
                    try:
                        with open(path, "rb") as f:
                            data = f.read()
                    except:
                        data = None
                    if data is not None:
                        output_files.append((name, path, data))

        results.append(
            ShellCommandResult(
                cmd.commands[i],
                out,
                err,
                res,
                timeoutHelper.timeoutReached(),
                output_files,
            )
        )
        if cmd.pipe_err:
            # Take the last failing exit code from the pipeline.
            if not exitCode or res != 0:
                exitCode = res
        else:
            exitCode = res

    # Remove any named temporary files we created.
    for f in named_temp_files:
        try:
            os.remove(f)
        except OSError:
            pass

    if cmd.negate:
        exitCode = not exitCode

    return exitCode


def findColor(line, curr_color):
    start = line.rfind("\33[")
    if start == -1:
        return curr_color
    end = line.find("m", start + 2)
    if end == -1:
        return curr_color
    match = line[start : end + 1]
    # "\33[0m" means "reset all formatting". Sometimes the 0 is skipped.
    if match == "\33[m" or match == "\33[0m":
        return None
    return match


def formatOutput(title, data, limit=None):
    if not data.strip():
        return ""
    if not limit is None and len(data) > limit:
        msg = (
            f"data was truncated ({limit}/{len(data)})"
            + " (change limit with -D output_limit=N)"
        )
        data = data[:limit] + "\n...\n"
    else:
        msg = ""
    ndashes = 30
    # fmt: off
    out = f"# .---{title}{'-' * (ndashes - 4 - len(title))}\n"
    curr_color = None
    for line in data.splitlines():
        if curr_color:
            out += "\33[0m"
        out += "# | "
        if curr_color:
            out += curr_color
        out += line + "\n"
        curr_color = findColor(line, curr_color)
    if curr_color:
        out += "\33[0m"  # prevent unterminated formatting from leaking
    out += f"# `---{msg}{'-' * (ndashes - 4 - len(msg))}\n"
    # fmt: on
    return out


# Always either returns the tuple (out, err, exitCode, timeoutInfo) or raises a
# ScriptFatal exception.
#
# If debug is True (the normal lit behavior), err is empty, and out contains an
# execution trace, including stdout and stderr shown per command executed.
#
# If debug is False (set by some custom lit test formats that call this
# function), out contains only stdout from the script, err contains only stderr
# from the script, and there is no execution trace.
def executeScriptInternal(
    test, litConfig, tmpBase, commands, cwd, debug=True
) -> tuple[str, str, int, str | None, str | None]:
    cmds = []
    update_output = None
    for i, ln in enumerate(commands):
        # Within lit, we try to always add '%dbg(...)' to command lines in order
        # to maximize debuggability.  However, custom lit test formats might not
        # always add it, so add a generic debug message in that case.
        match = re.fullmatch(kPdbgRegex, ln)
        if match:
            dbg = match.group(1)
            command = match.group(2)
        else:
            dbg = "command line"
            command = ln
        if debug:
            ln = f"@echo '# {dbg}' "
            if command:
                ln += f"&& @echo {shlex.quote(command.lstrip())} && {command}"
            else:
                ln += "has no command after substitutions"
        else:
            ln = command
        try:
            cmds.append(
                ShUtil.ShParser(ln, litConfig.isWindows, test.config.pipefail).parse()
            )
        except:
            raise ScriptFatal(
                f"shell parser error on {dbg}: {command.lstrip()}\n"
            ) from None

    # Link all of `cmds` into a single command, consisting of the original
    # commands chained together with &&. To avoid RecursionError in large tests
    # (e.g. with 1000 RUN: lines), we do this by subdividing the list in half
    # each time, so that we make a balanced tree structure with depth
    # proportional to only the log of the list length.
    def make_tree(cmds):
        if len(cmds) == 1:
            return cmds[0]
        else:
            assert len(cmds) > 1, "didn't expect an empty sequence"
            split = len(cmds) // 2
            return ShUtil.Seq(make_tree(cmds[:split]), "&&", make_tree(cmds[split:]))

    cmd = make_tree(cmds)

    results = []
    timeoutInfo = None
    normalize_slashes = litConfig.params.get("use_normalized_slashes", False)
    shenv = ShellEnvironment(
        cwd, test.config.environment, normalize_slashes=normalize_slashes
    )
    shenv.env["LIT_CURRENT_TESTCASE"] = test.getFullName()

    exitCode, timeoutInfo = executeShCmd(
        cmd, shenv, results, timeout=test.config.maxIndividualTestTime
    )

    out = err = ""
    for i, result in enumerate(results):
        if not debug:
            out += result.stdout
            err += result.stderr
            continue

        # The purpose of an "@echo" command is merely to add a debugging message
        # directly to lit's output.  It is used internally by lit's internal
        # shell and is not currently documented for use in lit tests.  However,
        # if someone misuses it (e.g., both "echo" and "@echo" complain about
        # stdin redirection), produce the normal execution trace to facilitate
        # debugging.
        if (
            result.command.args[0] == "@echo"
            and result.exitCode == 0
            and not result.stderr
            and not result.outputFiles
            and not result.timeoutReached
        ):
            out += result.stdout
            continue

        # Write the command line that was run.  Properly quote it.  Leading
        # "!" commands should not be quoted as that would indicate they are not
        # the builtins.
        out += "# executed command: "
        nLeadingBangs = next(
            (i for i, cmd in enumerate(result.command.args) if cmd != "!"),
            len(result.command.args),
        )
        out += "! " * nLeadingBangs
        out += " ".join(
            shlex.quote(str(s))
            for i, s in enumerate(result.command.args)
            if i >= nLeadingBangs
        )
        out += "\n"

        # If nothing interesting happened, move on.
        if (
            test.config.maxIndividualTestTime == 0
            and result.exitCode == 0
            and not result.stdout.strip()
            and not result.stderr.strip()
        ):
            continue

        # Otherwise, something failed or was printed, show it.

        # Add the command output, if redirected.
        outputLimit = int(litConfig.params.get("output_limit", 10240))
        for (name, path, data) in result.outputFiles:
            data = data.decode("utf-8", errors="replace")
            out += formatOutput(
                f"redirected output from '{name}'", data, limit=outputLimit
            )
        if result.stdout.strip():
            out += formatOutput("command stdout", result.stdout, limit=outputLimit)
        if result.stderr.strip():
            out += formatOutput("command stderr", result.stderr, limit=outputLimit)
        if not result.stdout.strip() and not result.stderr.strip():
            out += "# note: command had no output on stdout or stderr\n"

        # Show the error conditions:
        if result.exitCode != 0:
            # On Windows, a negative exit code indicates a signal, and those are
            # easier to recognize or look up if we print them in hex.
            if litConfig.isWindows and (result.exitCode < 0 or result.exitCode > 255):
                codeStr = hex(int(result.exitCode & 0xFFFFFFFF)).rstrip("L")
            else:
                codeStr = str(result.exitCode)
            out += "# error: command failed with exit status: %s\n" % (codeStr,)
        if test.config.maxIndividualTestTime > 0 and result.timeoutReached:
            out += "# error: command reached timeout: %s\n" % (
                str(result.timeoutReached),
            )

        if (
            litConfig.update_tests
            and result.exitCode != 0
            and not timeoutInfo
            # In theory tests marked XFAIL can fail in the form of XPASS, but the
            # test updaters are not expected to be able to fix that, so always skip for XFAIL
            and not test.isExpectedToFail()
        ):
            for test_updater in litConfig.test_updaters:
                try:
                    update_output = test_updater(result, test, commands)
                except Exception as e:
                    output = out
                    output += err
                    output += "Exception occurred in test updater:\n"
                    output += traceback.format_exc()
                    raise TestUpdaterException(output)
                if update_output:
                    break

    return out, err, exitCode, timeoutInfo, update_output


def executeScript(
    test, litConfig, tmpBase, commands, cwd
) -> tuple[str, str, int, str | None, str | None]:
    bashPath = litConfig.getBashPath()
    isWin32CMDEXE = litConfig.isWindows and not bashPath
    script = tmpBase + ".script"
    if isWin32CMDEXE:
        script += ".bat"

    # Write script file
    if isWin32CMDEXE:
        for i, ln in enumerate(commands):
            match = re.fullmatch(kPdbgRegex, ln)
            if match:
                command = match.group(2)
                commands[i] = match.expand(
                    "echo '\\1' > nul && " if command else "echo '\\1' > nul"
                )
        with open(script, "w", encoding="utf-8") as f:
            f.write("@echo on\n")
            f.write("\n@if %ERRORLEVEL% NEQ 0 EXIT\n".join(commands))
    else:
        for i, ln in enumerate(commands):
            match = re.fullmatch(kPdbgRegex, ln)
            if match:
                dbg = match.group(1)
                command = match.group(2)
                # Echo the debugging diagnostic to stderr.
                #
                # For that echo command, use 'set' commands to suppress the
                # shell's execution trace, which would just add noise.  Suppress
                # the shell's execution trace for the 'set' commands by
                # redirecting their stderr to /dev/null.
                if command:
                    msg = f"{shlex.quote(command.lstrip())} \\# '{dbg}'"
                else:
                    msg = f"'{dbg}' has no command after substitutions"
                commands[i] = (
                    f"{{ set +x; }} 2>/dev/null && "
                    f"echo {msg} >&2 && "
                    f"{{ set -x; }} 2>/dev/null"
                )
                # Execute the command, if any.
                #
                # 'command' might be something like:
                #
                #   subcmd & PID=$!
                #
                # In that case, we need something like:
                #
                #   echo_dbg && { subcmd & PID=$!; }
                #
                # Without the '{ ...; }' enclosing the original 'command', '&'
                # would put all of 'echo_dbg && subcmd' in the background.  This
                # would cause 'echo_dbg' to execute at the wrong time, and a
                # later kill of $PID would target the wrong process. We have
                # seen the latter manage to terminate the shell running lit.
                if command:
                    commands[i] += f" && {{ {command}; }}"

        # Manually export any DYLD_* variables used by dyld on macOS because
        # otherwise they are lost when the shell executable is run, before the
        # lit test is executed.
        env_str = "\n".join(
            "export {}={};".format(k, shlex.quote(v))
            for k, v in test.config.environment.items()
            if k.startswith("DYLD_")
        )

        with open(script, "w", encoding="utf-8", newline="") as f:
            if test.config.pipefail:
                f.write("set -o pipefail;")
            f.write(env_str)
            f.write("set -x;")
            f.write("{ " + "; } &&\n{ ".join(commands) + "; }")
            f.write("\n")

    if isWin32CMDEXE:
        command = ["cmd", "/c", script]
    else:
        if bashPath:
            command = [bashPath, script]
        else:
            command = ["/bin/sh", script]
        if litConfig.useValgrind:
            # FIXME: Running valgrind on sh is overkill. We probably could just
            # run on clang with no real loss.
            command = litConfig.valgrindArgs + command

    env = dict(test.config.environment)
    env["LIT_CURRENT_TESTCASE"] = test.getFullName()
    try:
        out, err, exitCode = lit.util.executeCommand(
            command,
            cwd=cwd,
            env=env,
            timeout=test.config.maxIndividualTestTime,
        )
        return (out, err, exitCode, None, None)
    except lit.util.ExecuteCommandTimeoutException as e:
        return (e.out, e.err, e.exitCode, e.msg, None)


def parseIntegratedTestScriptCommands(source_path, keywords):
    """
    parseIntegratedTestScriptCommands(source_path) -> commands

    Parse the commands in an integrated test script file into a list of
    (line_number, command_type, line).
    """

    # We use `bytes` for scanning input files to avoid requiring them to always
    # have valid codings.

    keywords_re = re.compile(
        b"(%s)(.*)\n" % (b"|".join(re.escape(k.encode("utf-8")) for k in keywords),)
    )

    f = open(source_path, "rb")
    try:
        # Read the entire file contents.
        data = f.read()

        # Ensure the data ends with a newline.
        if not data.endswith(b"\n"):
            data = data + b"\n"

        # Iterate over the matches.
        line_number = 1
        last_match_position = 0
        for match in keywords_re.finditer(data):
            # Compute the updated line number by counting the intervening
            # newlines.
            match_position = match.start()
            line_number += data.count(b"\n", last_match_position, match_position)
            last_match_position = match_position

            # Convert the keyword and line to UTF-8 strings and yield the
            # command.
            #
            # Opening the file in binary mode prevented Windows \r newline
            # characters from being converted to Unix \n newlines, so manually
            # strip those from the yielded lines.
            keyword, ln = match.groups()
            yield (
                line_number,
                keyword.decode("utf-8"),
                ln.decode("utf-8").rstrip("\r"),
            )
    finally:
        f.close()


def getTempPaths(test):
    """Get the temporary location, this is always relative to the test suite
    root, not test source root."""
    execpath = test.getExecPath()
    execdir, execbase = os.path.split(execpath)
    tmpDir = os.path.join(execdir, "Output")
    tmpBase = os.path.join(tmpDir, execbase)
    return tmpDir, tmpBase


def colonNormalizePath(path):
    if kIsWindows:
        return re.sub(r"^(.):", r"\1", path.replace("\\", "/"))
    else:
        assert path[0] == "/"
        return path[1:]


def getDefaultSubstitutions(test, tmpDir, tmpBase, normalize_slashes=False):
    sourcepath = test.getSourcePath()
    sourcedir = os.path.dirname(sourcepath)

    # Normalize slashes, if requested.
    if normalize_slashes:
        sourcepath = sourcepath.replace("\\", "/")
        sourcedir = sourcedir.replace("\\", "/")
        tmpDir = tmpDir.replace("\\", "/")
        tmpBase = tmpBase.replace("\\", "/")

    substitutions = []
    substitutions.extend(test.config.substitutions)
    tmpName = tmpBase + ".tmp"
    tmpBaseName = os.path.basename(tmpBase)
    sourceBaseName = os.path.basename(sourcepath)
    sourceStem = os.path.splitext(sourceBaseName)[0]

    substitutions.append(("%{pathsep}", os.pathsep))
    substitutions.append(("%basename_t", tmpBaseName))

    substitutions.append(("%{s:basename}", sourceBaseName))
    substitutions.append(("%{s:stem}", sourceStem))
    substitutions.append(("%{t:stem}", tmpBaseName))

    fs_sep = os.path.sep
    if normalize_slashes:
        fs_sep = "/"

    substitutions.extend(
        [
            (
                "%{fs-src-root}",
                pathlib.Path(sourcedir).anchor.replace("\\", "/")
                if normalize_slashes
                else pathlib.Path(sourcedir).anchor,
            ),
            (
                "%{fs-tmp-root}",
                pathlib.Path(tmpBase).anchor.replace("\\", "/")
                if normalize_slashes
                else pathlib.Path(tmpBase).anchor,
            ),
            ("%{fs-sep}", fs_sep),
        ]
    )

    substitutions.append(("%/et", tmpName.replace("\\", "\\\\\\\\\\\\\\\\")))

    def regex_escape(s):
        s = s.replace("@", r"\@")
        s = s.replace("&", r"\&")
        return s

    path_substitutions = [
        ("s", sourcepath),
        ("S", sourcedir),
        ("p", sourcedir),
        ("t", tmpName),
    ]
    for path_substitution in path_substitutions:
        letter = path_substitution[0]
        path = path_substitution[1]

        # Original path variant
        substitutions.append(("%" + letter, path))

        # Normalized path separator variant
        substitutions.append(("%/" + letter, path.replace("\\", "/")))

        # realpath variants
        # Windows paths with substitute drives are not expanded by default
        # as they are used to avoid MAX_PATH issues, but sometimes we do
        # need the fully expanded path.
        real_path = os.path.realpath(path)
        substitutions.append(("%{" + letter + ":real}", real_path))
        substitutions.append(("%{/" + letter + ":real}",
            real_path.replace("\\", "/")))

        # "%{/[STpst]:regex_replacement}" should be normalized like
        # "%/[STpst]" but we're also in a regex replacement context
        # of a s@@@ regex.
        substitutions.append(
            ("%{/" + letter + ":regex_replacement}",
            regex_escape(path.replace("\\", "/"))))

        # "%:[STpst]" are normalized paths without colons and without
        # a leading slash.
        substitutions.append(("%:" + letter, colonNormalizePath(path)))

    return substitutions


@lit.util.memoize  # Intentionally unbounded: see applySubstitutions
def _caching_re_compile(r):
    return re.compile(r)

class ExpandableScriptDirective:
    """
    Common interface for lit directives for which any lit substitutions must be
    expanded to produce the shell script.  It includes directives (e.g., 'RUN:')
    specifying shell commands that might have lit substitutions to be expanded.
    It also includes lit directives (e.g., 'DEFINE:') that adjust substitutions.

    start_line_number: The directive's starting line number.
    end_line_number: The directive's ending line number, which is
        start_line_number if the directive has no line continuations.
    keyword: The keyword that specifies the directive.  For example, 'RUN:'.
    """

    def __init__(self, start_line_number, end_line_number, keyword):
        # Input line number where the directive starts.
        self.start_line_number = start_line_number
        # Input line number where the directive ends.
        self.end_line_number = end_line_number
        # The keyword used to indicate the directive.
        self.keyword = keyword

    def add_continuation(self, line_number, keyword, line):
        """
        Add a continuation line to this directive and return True, or do nothing
        and return False if the specified line is not a continuation for this
        directive (e.g., previous line does not end in '\', or keywords do not
        match).

        line_number: The line number for the continuation line.
        keyword: The keyword that specifies the continuation line.  For example,
            'RUN:'.
        line: The content of the continuation line after the keyword.
        """
        assert False, "expected method to be called on derived class"

    def needs_continuation(self):
        """
        Does this directive require a continuation line?

        '\' is documented as indicating a line continuation even if whitespace
        separates it from the newline.  It looks like a line continuation, and
        it would be confusing if it didn't behave as one.
        """
        assert False, "expected method to be called on derived class"

    def get_location(self):
        """
        Get a phrase describing the line or range of lines so far included by
        this directive and any line continuations.
        """
        if self.start_line_number == self.end_line_number:
            return f"at line {self.start_line_number}"
        return f"from line {self.start_line_number} to {self.end_line_number}"


class CommandDirective(ExpandableScriptDirective):
    """
    A lit directive taking a shell command line.  For example,
    'RUN: echo hello world'.

    command: The content accumulated so far from the directive and its
        continuation lines.
    """

    def __init__(self, start_line_number, end_line_number, keyword, line):
        super().__init__(start_line_number, end_line_number, keyword)
        self.command = line.rstrip()

    def add_continuation(self, line_number, keyword, line):
        if keyword != self.keyword or not self.needs_continuation():
            return False
        self.command = self.command[:-1] + line.rstrip()
        self.end_line_number = line_number
        return True

    def needs_continuation(self):
        # Trailing whitespace is stripped immediately when each line is added,
        # so '\' is never hidden here.
        return self.command[-1] == "\\"


class SubstDirective(ExpandableScriptDirective):
    """
    A lit directive taking a substitution definition or redefinition.  For
    example, 'DEFINE: %{name} = value'.

    new_subst: True if this directive defines a new substitution.  False if it
        redefines an existing substitution.
    body: The unparsed content accumulated so far from the directive and its
        continuation lines.
    name: The substitution's name, or None if more continuation lines are still
        required.
    value: The substitution's value, or None if more continuation lines are
        still required.
    """

    def __init__(self, start_line_number, end_line_number, keyword, new_subst, line):
        super().__init__(start_line_number, end_line_number, keyword)
        self.new_subst = new_subst
        self.body = line
        self.name = None
        self.value = None
        self._parse_body()

    def add_continuation(self, line_number, keyword, line):
        if keyword != self.keyword or not self.needs_continuation():
            return False
        if not line.strip():
            raise ValueError("Substitution's continuation is empty")
        # Append line.  Replace the '\' and any adjacent whitespace with a
        # single space.
        self.body = self.body.rstrip()[:-1].rstrip() + " " + line.lstrip()
        self.end_line_number = line_number
        self._parse_body()
        return True

    def needs_continuation(self):
        return self.body.rstrip()[-1:] == "\\"

    def _parse_body(self):
        """
        If no more line continuations are required, parse all the directive's
        accumulated lines in order to identify the substitution's name and full
        value, and raise an exception if invalid.
        """
        if self.needs_continuation():
            return

        # Extract the left-hand side and value, and discard any whitespace
        # enclosing each.
        parts = self.body.split("=", 1)
        if len(parts) == 1:
            raise ValueError("Substitution's definition does not contain '='")
        self.name = parts[0].strip()
        self.value = parts[1].strip()

        # Check the substitution's name.
        #
        # Do not extend this to permit '.' or any sequence that's special in a
        # python pattern.  We could escape that automatically for
        # DEFINE/REDEFINE directives in test files.  However, lit configuration
        # file authors would still have to remember to escape them manually in
        # substitution names but not in values.  Moreover, the manually chosen
        # and automatically chosen escape sequences would have to be consistent
        # (e.g., '\.' vs. '[.]') in order for REDEFINE to successfully redefine
        # a substitution previously defined by a lit configuration file.  All
        # this seems too error prone and confusing to be worthwhile.  If you
        # want your name to express structure, use ':' instead of '.'.
        #
        # Actually, '{' and '}' are special if they contain only digits possibly
        # separated by a comma.  Requiring a leading letter avoids that.
        if not re.fullmatch(r"%{[_a-zA-Z][-_:0-9a-zA-Z]*}", self.name):
            raise ValueError(
                f"Substitution name '{self.name}' is malformed as it must "
                f"start with '%{{', it must end with '}}', and the rest must "
                f"start with a letter or underscore and contain only "
                f"alphanumeric characters, hyphens, underscores, and colons"
            )

    def adjust_substitutions(self, substitutions):
        """
        Modify the specified substitution list as specified by this directive.
        """
        assert (
            not self.needs_continuation()
        ), "expected directive continuations to be parsed before applying"
        existing = [i for i, subst in enumerate(substitutions) if self.name in subst[0]]
        existing_res = "".join(
            "\nExisting pattern: " + substitutions[i][0] for i in existing
        )
        if self.new_subst:
            if existing:
                raise ValueError(
                    f"Substitution whose pattern contains '{self.name}' is "
                    f"already defined before '{self.keyword}' directive "
                    f"{self.get_location()}"
                    f"{existing_res}"
                )
            substitutions.insert(0, (self.name, self.value))
            return
        if len(existing) > 1:
            raise ValueError(
                f"Multiple substitutions whose patterns contain '{self.name}' "
                f"are defined before '{self.keyword}' directive "
                f"{self.get_location()}"
                f"{existing_res}"
            )
        if not existing:
            raise ValueError(
                f"No substitution for '{self.name}' is defined before "
                f"'{self.keyword}' directive {self.get_location()}"
            )
        if substitutions[existing[0]][0] != self.name:
            raise ValueError(
                f"Existing substitution whose pattern contains '{self.name}' "
                f"does not have the pattern specified by '{self.keyword}' "
                f"directive {self.get_location()}\n"
                f"Expected pattern: {self.name}"
                f"{existing_res}"
            )
        substitutions[existing[0]] = (self.name, self.value)


def applySubstitutions(script, substitutions, conditions={}, recursion_limit=None):
    """
    Apply substitutions to the script.  Allow full regular expression syntax.
    Replace each matching occurrence of regular expression pattern a with
    substitution b in line ln.

    If a substitution expands into another substitution, it is expanded
    recursively until the line has no more expandable substitutions. If
    the line can still can be substituted after being substituted
    `recursion_limit` times, it is an error. If the `recursion_limit` is
    `None` (the default), no recursive substitution is performed at all.
    """

    # We use #_MARKER_# to hide %% while we do the other substitutions.
    def escapePercents(ln):
        return _caching_re_compile("%%").sub("#_MARKER_#", ln)

    def unescapePercents(ln):
        return _caching_re_compile("#_MARKER_#").sub("%", ln)

    def substituteIfElse(ln):
        # early exit to avoid wasting time on lines without
        # conditional substitutions
        if ln.find("%if ") == -1:
            return ln

        def tryParseIfCond(ln):
            # space is important to not conflict with other (possible)
            # substitutions
            if not ln.startswith("%if "):
                return None, ln
            ln = ln[4:]

            # stop at '%{'
            match = _caching_re_compile("%{").search(ln)
            if not match:
                raise ValueError("'%{' is missing for %if substitution")
            cond = ln[: match.start()]

            # eat '%{' as well
            ln = ln[match.end() :]
            return cond, ln

        def tryParseElse(ln):
            match = _caching_re_compile(r"^\s*%else\s*(%{)?").search(ln)
            if not match:
                return False, ln
            if not match.group(1):
                raise ValueError("'%{' is missing for %else substitution")
            return True, ln[match.end() :]

        def tryParseEnd(ln):
            if ln.startswith("%}"):
                return True, ln[2:]
            return False, ln

        def parseText(ln, isNested):
            # parse everything until %if, or %} if we're parsing a
            # nested expression.
            match = _caching_re_compile(
                "(.*?)(?:%if|%})" if isNested else "(.*?)(?:%if)"
            ).search(ln)
            if not match:
                # there is no terminating pattern, so treat the whole
                # line as text
                return ln, ""
            text_end = match.end(1)
            return ln[:text_end], ln[text_end:]

        def parseRecursive(ln, isNested):
            result = ""
            while len(ln):
                if isNested:
                    found_end, _ = tryParseEnd(ln)
                    if found_end:
                        break

                # %if cond %{ branch_if %} %else %{ branch_else %}
                cond, ln = tryParseIfCond(ln)
                if cond:
                    branch_if, ln = parseRecursive(ln, isNested=True)
                    found_end, ln = tryParseEnd(ln)
                    if not found_end:
                        raise ValueError("'%}' is missing for %if substitution")

                    branch_else = ""
                    found_else, ln = tryParseElse(ln)
                    if found_else:
                        branch_else, ln = parseRecursive(ln, isNested=True)
                        found_end, ln = tryParseEnd(ln)
                        if not found_end:
                            raise ValueError("'%}' is missing for %else substitution")

                    if BooleanExpression.evaluate(cond, conditions):
                        result += branch_if
                    else:
                        result += branch_else
                    continue

                # The rest is handled as plain text.
                text, ln = parseText(ln, isNested)
                result += text

            return result, ln

        result, ln = parseRecursive(ln, isNested=False)
        assert len(ln) == 0
        return result

    def processLine(ln):
        # Apply substitutions
        ln = substituteIfElse(escapePercents(ln))
        for a, b in substitutions:
            b = b.replace("\\", "\\\\")
            # re.compile() has a built-in LRU cache with 512 entries. In some
            # test suites lit ends up thrashing that cache, which made e.g.
            # check-llvm run 50% slower.  Use an explicit, unbounded cache
            # to prevent that from happening.  Since lit is fairly
            # short-lived, since the set of substitutions is fairly small, and
            # since thrashing has such bad consequences, not bounding the cache
            # seems reasonable.
            ln = _caching_re_compile(a).sub(str(b), escapePercents(ln))

        # Strip the trailing newline and any extra whitespace.
        return ln.strip()

    def processLineToFixedPoint(ln):
        assert isinstance(recursion_limit, int) and recursion_limit >= 0
        origLine = ln
        steps = 0
        processed = processLine(ln)
        while processed != ln and steps < recursion_limit:
            ln = processed
            processed = processLine(ln)
            steps += 1

        if processed != ln:
            raise ValueError(
                "Recursive substitution of '%s' did not complete "
                "in the provided recursion limit (%s)" % (origLine, recursion_limit)
            )

        return processed

    process = processLine if recursion_limit is None else processLineToFixedPoint
    output = []
    for directive in script:
        if isinstance(directive, SubstDirective):
            directive.adjust_substitutions(substitutions)
        else:
            if isinstance(directive, CommandDirective):
                line = directive.command
            else:
                # Can come from preamble_commands.
                assert isinstance(directive, str)
                line = directive
            output.append(unescapePercents(process(line)))

    return output


@enum.unique
class ParserKind(enum.IntEnum):
    """
    An enumeration representing the style of an integrated test keyword or
    command.

    TAG: A keyword taking no value. Ex 'END.'
    COMMAND: A keyword taking a list of shell commands. Ex 'RUN:'
    LIST: A keyword taking a comma-separated list of values.
    SPACE_LIST: A keyword taking a space-separated list of values.
    BOOLEAN_EXPR: A keyword taking a comma-separated list of
        boolean expressions. Ex 'XFAIL:'
    INTEGER: A keyword taking a single integer. Ex 'ALLOW_RETRIES:'
    CUSTOM: A keyword with custom parsing semantics.
    DEFINE: A keyword taking a new lit substitution definition. Ex
        'DEFINE: %{name}=value'
    REDEFINE: A keyword taking a lit substitution redefinition. Ex
        'REDEFINE: %{name}=value'
    """

    def __new__(cls, value, suffixes):
        obj = int.__new__(cls, value)
        obj._value_ = value
        obj.allowed_suffixes = suffixes
        return obj

    TAG = (0, ["."])
    COMMAND = (1, [":"])
    LIST = (2, [":"])
    SPACE_LIST = (3, [":"])
    BOOLEAN_EXPR = (4, [":"])
    INTEGER = (5, [":"])
    CUSTOM = (6, [":", "."])
    DEFINE = (7, [":"])
    REDEFINE = (8, [":"])


class IntegratedTestKeywordParser:
    """A parser for LLVM/Clang style integrated test scripts.

    keyword: The keyword to parse for. It must end in either '.' or ':'.
    kind: An value of ParserKind.
    parser: A custom parser. This value may only be specified with
            ParserKind.CUSTOM.
    """

    def __init__(self, keyword, kind, parser=None, initial_value=None):
        allowedSuffixes = kind.allowed_suffixes
        if len(keyword) == 0 or keyword[-1] not in allowedSuffixes:
            if len(allowedSuffixes) == 1:
                raise ValueError(
                    "Keyword '%s' of kind '%s' must end in '%s'"
                    % (keyword, kind.name, allowedSuffixes[0])
                )
            else:
                raise ValueError(
                    "Keyword '%s' of kind '%s' must end in "
                    " one of '%s'" % (keyword, kind.name, " ".join(allowedSuffixes))
                )

        if parser is not None and kind != ParserKind.CUSTOM:
            raise ValueError(
                "custom parsers can only be specified with " "ParserKind.CUSTOM"
            )
        self.keyword = keyword
        self.kind = kind
        self.parsed_lines = []
        self.value = initial_value
        self.parser = parser

        if kind == ParserKind.COMMAND:
            self.parser = lambda line_number, line, output: self._handleCommand(
                line_number, line, output, self.keyword
            )
        elif kind == ParserKind.LIST:
            self.parser = self._handleList
        elif kind == ParserKind.SPACE_LIST:
            self.parser = self._handleSpaceList
        elif kind == ParserKind.BOOLEAN_EXPR:
            self.parser = self._handleBooleanExpr
        elif kind == ParserKind.INTEGER:
            self.parser = self._handleSingleInteger
        elif kind == ParserKind.TAG:
            self.parser = self._handleTag
        elif kind == ParserKind.CUSTOM:
            if parser is None:
                raise ValueError("ParserKind.CUSTOM requires a custom parser")
            self.parser = parser
        elif kind == ParserKind.DEFINE:
            self.parser = lambda line_number, line, output: self._handleSubst(
                line_number, line, output, self.keyword, new_subst=True
            )
        elif kind == ParserKind.REDEFINE:
            self.parser = lambda line_number, line, output: self._handleSubst(
                line_number, line, output, self.keyword, new_subst=False
            )
        else:
            raise ValueError("Unknown kind '%s'" % kind)

    def parseLine(self, line_number, line):
        try:
            self.parsed_lines += [(line_number, line)]
            self.value = self.parser(line_number, line, self.value)
        except ValueError as e:
            raise ValueError(
                str(e)
                + ("\nin %s directive on test line %d" % (self.keyword, line_number))
            )

    def getValue(self):
        return self.value

    @staticmethod
    def _handleTag(line_number, line, output):
        """A helper for parsing TAG type keywords"""
        return not line.strip() or output

    @staticmethod
    def _substituteLineNumbers(line_number, line):
        line = re.sub(r"%\(line\)", str(line_number), line)

        def replace_line_number(match):
            if match.group(1) == "+":
                return str(line_number + int(match.group(2)))
            if match.group(1) == "-":
                return str(line_number - int(match.group(2)))

        return re.sub(r"%\(line *([\+-]) *(\d+)\)", replace_line_number, line)

    @classmethod
    def _handleCommand(cls, line_number, line, output, keyword):
        """A helper for parsing COMMAND type keywords"""
        # Substitute line number expressions.
        line = cls._substituteLineNumbers(line_number, line)

        # Collapse lines with trailing '\\', or add line with line number to
        # start a new pipeline.
        if not output or not output[-1].add_continuation(line_number, keyword, line):
            if output is None:
                output = []
            line = buildPdbgCommand(f"{keyword} at line {line_number}", line)
            output.append(CommandDirective(line_number, line_number, keyword, line))
        return output

    @staticmethod
    def _handleList(line_number, line, output):
        """A parser for LIST type keywords"""
        if output is None:
            output = []
        output.extend([s.strip() for s in line.split(",")])
        return output

    @staticmethod
    def _handleSpaceList(line_number, line, output):
        """A parser for SPACE_LIST type keywords"""
        if output is None:
            output = []
        output.extend([s.strip() for s in line.split(" ") if s.strip() != ""])
        return output

    @staticmethod
    def _handleSingleInteger(line_number, line, output):
        """A parser for INTEGER type keywords"""
        if output is None:
            output = []
        try:
            n = int(line)
        except ValueError:
            raise ValueError(
                "INTEGER parser requires the input to be an integer (got {})".format(
                    line
                )
            )
        output.append(n)
        return output

    @staticmethod
    def _handleBooleanExpr(line_number, line, output):
        """A parser for BOOLEAN_EXPR type keywords"""
        parts = [s.strip() for s in line.split(",") if s.strip() != ""]
        if output and output[-1][-1] == "\\":
            output[-1] = output[-1][:-1] + parts[0]
            del parts[0]
        if output is None:
            output = []
        output.extend(parts)
        # Evaluate each expression to verify syntax.
        # We don't want any results, just the raised ValueError.
        for s in output:
            if s != "*" and not s.endswith("\\"):
                BooleanExpression.evaluate(s, [])
        return output

    @classmethod
    def _handleSubst(cls, line_number, line, output, keyword, new_subst):
        """A parser for DEFINE and REDEFINE type keywords"""
        line = cls._substituteLineNumbers(line_number, line)
        if output and output[-1].add_continuation(line_number, keyword, line):
            return output
        if output is None:
            output = []
        output.append(
            SubstDirective(line_number, line_number, keyword, new_subst, line)
        )
        return output


def _parseKeywords(sourcepath, additional_parsers=[], require_script=True):
    """_parseKeywords

    Scan an LLVM/Clang style integrated test script and extract all the lines
    pertaining to a special parser. This includes 'RUN', 'XFAIL', 'REQUIRES',
    'UNSUPPORTED', 'ALLOW_RETRIES', 'END', 'DEFINE', 'REDEFINE', as well as
    other specified custom parsers.

    Returns a dictionary mapping each custom parser to its value after
    parsing the test.
    """
    # Install the built-in keyword parsers.
    script = []
    builtin_parsers = [
        IntegratedTestKeywordParser("RUN:", ParserKind.COMMAND, initial_value=script),
        IntegratedTestKeywordParser("XFAIL:", ParserKind.BOOLEAN_EXPR),
        IntegratedTestKeywordParser("REQUIRES:", ParserKind.BOOLEAN_EXPR),
        IntegratedTestKeywordParser("UNSUPPORTED:", ParserKind.BOOLEAN_EXPR),
        IntegratedTestKeywordParser("ALLOW_RETRIES:", ParserKind.INTEGER),
        IntegratedTestKeywordParser("END.", ParserKind.TAG),
        IntegratedTestKeywordParser("DEFINE:", ParserKind.DEFINE, initial_value=script),
        IntegratedTestKeywordParser(
            "REDEFINE:", ParserKind.REDEFINE, initial_value=script
        ),
    ]
    keyword_parsers = {p.keyword: p for p in builtin_parsers}

    # Install user-defined additional parsers.
    for parser in additional_parsers:
        if not isinstance(parser, IntegratedTestKeywordParser):
            raise ValueError(
                "Additional parser must be an instance of "
                "IntegratedTestKeywordParser"
            )
        if parser.keyword in keyword_parsers:
            raise ValueError("Parser for keyword '%s' already exists" % parser.keyword)
        keyword_parsers[parser.keyword] = parser

    # Collect the test lines from the script.
    for line_number, command_type, ln in parseIntegratedTestScriptCommands(
        sourcepath, keyword_parsers.keys()
    ):
        parser = keyword_parsers[command_type]
        parser.parseLine(line_number, ln)
        if command_type == "END." and parser.getValue() is True:
            break

    # Verify the script contains a run line.
    if require_script and not any(
        isinstance(directive, CommandDirective) for directive in script
    ):
        raise ValueError("Test has no 'RUN:' line")

    # Check for unterminated run or subst lines.
    #
    # If, after a line continuation for one kind of directive (e.g., 'RUN:',
    # 'DEFINE:', 'REDEFINE:') in script, the next directive in script is a
    # different kind, then the '\\' remains on the former, and we report it
    # here.
    for directive in script:
        if directive.needs_continuation():
            raise ValueError(
                f"Test has unterminated '{directive.keyword}' "
                f"directive (with '\\') "
                f"{directive.get_location()}"
            )

    # Check boolean expressions for unterminated lines.
    for key in keyword_parsers:
        kp = keyword_parsers[key]
        if kp.kind != ParserKind.BOOLEAN_EXPR:
            continue
        value = kp.getValue()
        if value and value[-1][-1] == "\\":
            raise ValueError(
                "Test has unterminated '{key}' lines (with '\\')".format(key=key)
            )

    # Make sure there's at most one ALLOW_RETRIES: line
    allowed_retries = keyword_parsers["ALLOW_RETRIES:"].getValue()
    if allowed_retries and len(allowed_retries) > 1:
        raise ValueError("Test has more than one ALLOW_RETRIES lines")

    return {p.keyword: p.getValue() for p in keyword_parsers.values()}


def parseIntegratedTestScript(test, additional_parsers=[], require_script=True):
    """parseIntegratedTestScript - Scan an LLVM/Clang style integrated test
    script and extract the lines to 'RUN' as well as 'XFAIL', 'REQUIRES',
    'UNSUPPORTED' and 'ALLOW_RETRIES' information into the given test.

    If additional parsers are specified then the test is also scanned for the
    keywords they specify and all matches are passed to the custom parser.

    If 'require_script' is False an empty script
    may be returned. This can be used for test formats where the actual script
    is optional or ignored.
    """
    # Parse the test sources and extract test properties
    try:
        parsed = _parseKeywords(
            test.getSourcePath(), additional_parsers, require_script
        )
    except ValueError as e:
        return lit.Test.Result(Test.UNRESOLVED, str(e))
    script = parsed["RUN:"] or []
    assert parsed["DEFINE:"] == script
    assert parsed["REDEFINE:"] == script
    test.xfails += parsed["XFAIL:"] or []
    if test.exclude_xfail and test.isExpectedToFail():
        return lit.Test.Result(Test.EXCLUDED, "excluding XFAIL tests")
    test.requires += parsed["REQUIRES:"] or []
    test.unsupported += parsed["UNSUPPORTED:"] or []
    if parsed["ALLOW_RETRIES:"]:
        test.allowed_retries = parsed["ALLOW_RETRIES:"][0]

    # Enforce REQUIRES:
    missing_required_features = test.getMissingRequiredFeatures()
    if missing_required_features:
        msg = ", ".join(missing_required_features)
        return lit.Test.Result(
            Test.UNSUPPORTED,
            "Test requires the following unavailable " "features: %s" % msg,
        )

    # Enforce UNSUPPORTED:
    unsupported_features = test.getUnsupportedFeatures()
    if unsupported_features:
        msg = ", ".join(unsupported_features)
        return lit.Test.Result(
            Test.UNSUPPORTED,
            "Test does not support the following features " "and/or targets: %s" % msg,
        )

    # Enforce limit_to_features.
    if not test.isWithinFeatureLimits():
        msg = ", ".join(test.config.limit_to_features)
        return lit.Test.Result(
            Test.UNSUPPORTED,
            "Test does not require any of the features "
            "specified in limit_to_features: %s" % msg,
        )

    return script


def _runShTest(test, litConfig, useExternalSh, script, tmpBase) -> lit.Test.Result:
    # Always returns the tuple (out, err, exitCode, timeoutInfo, status).
    def runOnce(
        execdir,
    ) -> tuple[str, str, int, str | None, Test.ResultCode, str | None]:
        # script is modified below (for litConfig.per_test_coverage, and for
        # %dbg expansions).  runOnce can be called multiple times, but applying
        # the modifications multiple times can corrupt script, so always modify
        # a copy.
        scriptCopy = script[:]
        # Set unique LLVM_PROFILE_FILE for each run command
        if litConfig.per_test_coverage:
            # Use the test's full path in the suite, plus the %p (pid) and %m
            # (binary signature) runtime placeholders, so that distinct tests,
            # processes, and instrumented binaries don't share a profraw file.
            test_case_name = "_".join(test.path_in_suite)
            coverage_index = 0  # Counter for coverage file index
            for i, ln in enumerate(scriptCopy):
                match = re.fullmatch(kPdbgRegex, ln)
                if match:
                    dbg = match.group(1)
                    command = match.group(2)
                else:
                    command = ln
                profile = f"{test_case_name}-%p-%m{coverage_index}.profraw"
                coverage_index += 1
                command = f"export LLVM_PROFILE_FILE={profile}; {command}"
                if match:
                    command = buildPdbgCommand(dbg, command)
                scriptCopy[i] = command

        try:
            if useExternalSh:
                res = executeScript(test, litConfig, tmpBase, scriptCopy, execdir)
            else:
                res = executeScriptInternal(
                    test, litConfig, tmpBase, scriptCopy, execdir
                )
        except ScriptFatal as e:
            out = f"# " + "\n# ".join(str(e).splitlines()) + "\n"
            return out, "", 1, None, Test.UNRESOLVED, None

        out, err, exitCode, timeoutInfo, test_update_output = res
        if exitCode == 0:
            status = Test.PASS
        else:
            if timeoutInfo is None:
                status = Test.FAIL
            else:
                status = Test.TIMEOUT
        return out, err, exitCode, timeoutInfo, status, test_update_output

    # Create the output directory if it does not already exist.
    pathlib.Path(tmpBase).parent.mkdir(parents=True, exist_ok=True)

    # Re-run failed tests up to test.allowed_retries times.
    execdir = os.path.dirname(test.getExecPath())
    attempts = test.allowed_retries + 1
    test_updates = []
    for i in range(attempts):
        res = runOnce(execdir)
        out, err, exitCode, timeoutInfo, status, test_update_output = res
        test_updates.append(test_update_output)
        if status != Test.FAIL:
            break

    # If we had to run the test more than once, count it as a flaky pass. These
    # will be printed separately in the test summary.
    if i > 0 and status == Test.PASS:
        if any(test_updates):
            status = Test.FIXED
        else:
            status = Test.FLAKYPASS

    # Form the output log.
    output = f"Exit Code: {exitCode}\n"

    if timeoutInfo is not None:
        output += """Timeout: %s\n""" % (timeoutInfo,)
    output += "\n"

    # Append the outputs, if present.
    if out:
        output += """Command Output (stdout):\n--\n%s\n--\n""" % (out,)
    if err:
        output += """Command Output (stderr):\n--\n%s\n--\n""" % (err,)

    return lit.Test.Result(
        status,
        output,
        attempts=i + 1,
        max_allowed_attempts=attempts,
        test_updater_outputs=test_updates,
    )


def _expandLateSubstitutionsExternal(commandLine):
    filePaths = []

    def _replaceReadFile(match):
        filePath = match.group(1)
        filePaths.append(filePath)
        return "$(cat %s)" % shlex.quote(filePath)

    commandLine = re.sub(r"%{readfile:([^}]*)}", _replaceReadFile, commandLine)
    # Add test commands before the command to check if the file exists as
    # cat inside a subshell will never return a non-zero exit code outside
    # of the subshell.
    for filePath in filePaths:
        commandLine = "%s && test -e %s" % (commandLine, filePath)
    return commandLine

def executeShTest(
    test, litConfig, useExternalSh, extra_substitutions=[], preamble_commands=[]
):
    if test.config.unsupported:
        return lit.Test.Result(Test.UNSUPPORTED, "Test is unsupported")

    script = list(preamble_commands)
    script = [buildPdbgCommand(f"preamble command line", ln) for ln in script]

    parsed = parseIntegratedTestScript(test, require_script=not script)
    if isinstance(parsed, lit.Test.Result):
        return parsed
    script += parsed

    if litConfig.noExecute:
        return lit.Test.Result(Test.PASS)

    tmpDir, tmpBase = getTempPaths(test)
    substitutions = list(extra_substitutions)
    substitutions += getDefaultSubstitutions(
        test,
        tmpDir,
        tmpBase,
        normalize_slashes=useExternalSh
        or litConfig.params.get("use_normalized_slashes", False),
    )
    conditions = {feature: True for feature in test.config.available_features}
    script = applySubstitutions(
        script,
        substitutions,
        conditions,
        recursion_limit=test.config.recursiveExpansionLimit,
    )

    if useExternalSh:
        for index, command in enumerate(script):
            script[index] = _expandLateSubstitutionsExternal(command)

    return _runShTest(test, litConfig, useExternalSh, script, tmpBase)
